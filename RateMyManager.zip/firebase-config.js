import { initializeApp } from 'https://www.gstatic.com/firebasejs/9.22.0/firebase-app.js';
import { getDatabase, ref, push, onValue } from 'https://www.gstatic.com/firebasejs/9.22.0/firebase-database.js';

const firebaseConfig = {
  apiKey: "AIzaSyC21ZiRQs0XUwG4Kr02UaDZsf3D-1efApU",
  authDomain: "ratemymanager-2ce08.firebaseapp.com",
  databaseURL: "https://ratemymanager-2ce08-default-rtdb.firebaseio.com",
  projectId: "ratemymanager-2ce08",
  storageBucket: "ratemymanager-2ce08.appspot.com",
  messagingSenderId: "564802378390",
  appId: "1:564802378390:web:cf26b5051cd3a7adf4c0b7",
  measurementId: "G-VXH4RNSN0G"
};

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);
export { db, ref, push, onValue };
