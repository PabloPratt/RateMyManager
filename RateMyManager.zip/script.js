import { db, ref, push, onValue } from './firebase-config.js';

const form = document.getElementById('review-form');
const confirmation = document.getElementById('confirmation');
const reviewsDiv = document.getElementById('reviews');

form.addEventListener('submit', async (e) => {
  e.preventDefault();

  const managerName = document.getElementById('managerName').value;
  const department = document.getElementById('department').value;
  const rating = document.getElementById('rating').value;
  const compensation = document.getElementById('compensation').value;
  const split = document.getElementById('split').value;
  const review = document.getElementById('review').value;

  const reviewData = {
    managerName,
    department,
    rating,
    compensation,
    split,
    review,
    timestamp: Date.now()
  };

  await push(ref(db, 'reviews'), reviewData);
  form.reset();
  confirmation.classList.remove('hidden');
  setTimeout(() => confirmation.classList.add('hidden'), 3000);
});

onValue(ref(db, 'reviews'), (snapshot) => {
  const reviews = snapshot.val();
  reviewsDiv.innerHTML = '';
  for (let id in reviews) {
    const { managerName, department, rating, compensation, split, review } = reviews[id];
    const reviewEl = document.createElement('div');
    reviewEl.innerHTML = `<strong>${managerName}</strong> (${department}) - ⭐ ${rating}/5<br>
                          💰 Total Compensation: $${compensation} (${split})<br>
                          <p>${review}</p><hr>`;
    reviewsDiv.prepend(reviewEl);
  }
});
